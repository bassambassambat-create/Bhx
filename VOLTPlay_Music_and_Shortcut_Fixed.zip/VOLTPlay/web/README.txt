VOLTPlay folder
===============
1. Extract the entire ZIP.
2. Run CLICK ME - VOLTPlay.cmd.
3. Choose Install Yes/No, shortcut Yes/No, and Open VOLTPlay Yes/No.
4. In VOLTPlay, click Play to open the bundled Game Explorer; use VOLTPlay Menu to return.
Node.js and internet access are needed to install dependencies the first time.
