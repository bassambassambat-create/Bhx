const { app, BrowserWindow, shell, dialog } = require('electron');
const path = require('path');
const fs = require('fs');

function createWindow() {
  const entryFile = path.join(__dirname, 'web', 'VOLTPlay.html');
  if (!fs.existsSync(entryFile)) {
    dialog.showErrorBox(
      'VOLTPlay files missing',
      'Could not find web/VOLTPlay.html. Please extract the entire VOLTPlay app ZIP before starting.'
    );
    app.quit();
    return;
  }

  const iconFile = path.join(__dirname, 'web', 'VOLTPlay.ico');
  const win = new BrowserWindow({
    width: 1280,
    height: 820,
    minWidth: 900,
    minHeight: 600,
    title: 'VOLTPlay',
    ...(fs.existsSync(iconFile) ? { icon: iconFile } : {}),
    autoHideMenuBar: true,
    backgroundColor: '#101014',
    webPreferences: {
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true
    }
  });

  win.loadFile(entryFile);
  win.webContents.setWindowOpenHandler(({ url }) => {
    if (url.startsWith('https://') || url.startsWith('http://')) {
      shell.openExternal(url);
    }
    return { action: 'deny' };
  });
}

app.whenReady().then(() => {
  createWindow();
  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});
