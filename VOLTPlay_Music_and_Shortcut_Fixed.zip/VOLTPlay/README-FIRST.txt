VOLTPlay Desktop App — Windows

1) Extract this ZIP into a folder, for example Desktop\VOLTPlay-App.
2) Open PowerShell in that folder.
3) Run: npm.cmd install
4) To test the app: npm.cmd start
5) To build the Windows installer: npm.cmd run build
6) When the build finishes, look inside the dist folder for the VOLTPlay Setup .exe.

The installer is not precompiled in this ZIP; the build command creates it on your Windows PC.
Your original HTML files are kept in the web folder. The main page launched by default is VOLTPlay.html.
