@echo off
setlocal EnableExtensions
title CLICK ME - VOLTPlay
cd /d "%~dp0"
color 0B

if not exist "%~dp0package.json" (
  echo ERROR: Project files are missing. Extract the complete ZIP first.
  pause
  exit /b 1
)
if not exist "%~dp0main.js" (
  echo ERROR: main.js is missing.
  pause
  exit /b 1
)
if not exist "%~dp0web\VOLTPlay.html" (
  echo ERROR: web\VOLTPlay.html is missing.
  pause
  exit /b 1
)
where node.exe >nul 2>nul
if errorlevel 1 (
  echo Node.js is required. Install it from https://nodejs.org/ and run this file again.
  pause
  exit /b 1
)

:installmenu
cls
echo.
echo  ==========================================
echo                VOLTPlay Setup
echo  ==========================================
echo.
echo  Do you want to install VOLTPlay components?
echo.
echo  1. Yes - Install
necho  2. No  - Exit
echo.
choice /c 12 /n /m "Choose 1 or 2: "
if errorlevel 2 goto done
if errorlevel 1 goto install

:install
cls
echo Installing / downloading required components...
echo This step requires an internet connection the first time.
call npm.cmd install
if errorlevel 1 (
  echo.
  echo Download failed. Check your internet connection and try again.
  pause
  exit /b 1
)
echo.
echo Download successful.
pause

:shortcutmenu
cls
echo.
echo  Do you want to create a shortcut?
echo.
echo  1. Yes
echo  2. No
echo.
choice /c 12 /n /m "Choose 1 or 2: "
if errorlevel 2 goto openmenu
if errorlevel 1 goto shortcut

:shortcut
set "VOLTPLAY_DIR=%~dp0"
set "VOLTPLAY_ICON=%~dp0web\VOLTPlay.ico"
set "VOLTPLAY_LINK_NAME=VOLTPlay.lnk"
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; $desktop=[Environment]::GetFolderPath('DesktopDirectory'); if ([string]::IsNullOrWhiteSpace($desktop)) { $desktop=(New-Object -ComObject WScript.Shell).SpecialFolders('Desktop') }; if (-not (Test-Path -LiteralPath $desktop)) { throw ('Desktop folder not found: '+$desktop) }; $link=Join-Path $desktop $env:VOLTPLAY_LINK_NAME; $electron=Join-Path $env:VOLTPLAY_DIR 'node_modules\electron\dist\electron.exe'; if (-not (Test-Path -LiteralPath $electron)) { throw ('Electron is not installed at: '+$electron) }; $ws=New-Object -ComObject WScript.Shell; $s=$ws.CreateShortcut($link); $s.TargetPath=$electron; $s.Arguments='"'+$env:VOLTPLAY_DIR+'"'; $s.WorkingDirectory=$env:VOLTPLAY_DIR; if (Test-Path -LiteralPath $env:VOLTPLAY_ICON) { $s.IconLocation=$env:VOLTPLAY_ICON }; $s.Description='VOLTPlay Desktop App'; $s.Save(); if (-not (Test-Path -LiteralPath $link)) { throw ('Shortcut was not created: '+$link) }; Write-Output ('Shortcut created: '+$link)"
if errorlevel 1 (
  echo Shortcut creation failed. See the PowerShell error above.
) else (
  echo Shortcut creation verified successfully.
)
pause

:openmenu
cls
echo.
echo  Do you want to open VOLTPlay?
echo.
echo  1. Yes
echo  2. No
echo.
choice /c 12 /n /m "Choose 1 or 2: "
if errorlevel 2 goto done
if errorlevel 1 goto openapp

:openapp
if not exist "%~dp0node_modules\electron\dist\electron.exe" (
  echo Components are not installed. Please run Install and choose Yes first.
  pause
  goto done
)
echo Starting VOLTPlay...
call npm.cmd start
if errorlevel 1 (
  echo VOLTPlay did not start. Take a screenshot of this CMD window.
  pause
)
goto done

:done
echo.
echo Closing VOLTPlay setup.
exit /b 0
